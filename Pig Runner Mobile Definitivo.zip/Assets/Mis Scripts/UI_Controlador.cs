using UnityEngine;
using UnityEngine.UIElements;

public class UI_Controlador : MonoBehaviour
{
    public static UI_Controlador Instance;

    private Label coinText;
    private int monedas = 0;

    private void Awake()
    {
        Instance = this;
    }

    private void OnEnable()
    {
        var root = GetComponent<UIDocument>().rootVisualElement;

        coinText = root.Q<Label>("coinText");

        ActualizarUI();
    }

    public void SumarMoneda()
    {
        monedas++;
        ActualizarUI();
    }

    private void ActualizarUI()
    {
        if (coinText != null)
            coinText.text = $"{monedas} Monedas";
    }

    
}
