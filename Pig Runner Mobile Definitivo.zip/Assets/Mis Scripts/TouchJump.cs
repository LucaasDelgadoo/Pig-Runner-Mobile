using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.EventSystems;

[RequireComponent(typeof(Rigidbody2D))]
public class TouchJump : MonoBehaviour
{
    [Header("Configuración de Salto")]
    public float fuerzaSalto = 7f;
    public Transform groundCheck;
    public LayerMask groundLayer;
    public float margenSalto = 0.12f;

    private Rigidbody2D rb;
    private bool puedeSaltar;
    private bool deseaSaltar;

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        // 1. Detectar el toque inicial en la pantalla (o clic de ratón)
        if (Pointer.current != null && Pointer.current.press.wasPressedThisFrame)
        {
            // 2. IMPORTANTE: Solo saltar si NO estamos tocando la UI (Joystick/Monedas)
            if (!IsPointerOverUI())
            {
                deseaSaltar = true;
            }
        }
    }

    void FixedUpdate()
    {
        // Comprobar si el personaje está tocando el suelo
        ActualizarDeteccionSuelo();

        // Aplicar el salto si se detectó el toque y hay suelo
        if (deseaSaltar)
        {
            if (puedeSaltar)
            {
                // Aplicamos fuerza en Y manteniendo la velocidad horizontal actual
                rb.linearVelocity = new Vector2(rb.linearVelocity.x, fuerzaSalto);
            }
            deseaSaltar = false; // Resetear el deseo de salto tras procesarlo
        }
    }

    private void ActualizarDeteccionSuelo()
    {
        // Raycast hacia abajo para verificar contacto con el suelo
        RaycastHit2D hit = Physics2D.Raycast(groundCheck.position, Vector2.down, margenSalto, groundLayer);
        puedeSaltar = hit.collider != null;

        // Visualización en la pestaña Scene (Verde = Suelo | Rojo = Aire)
        Debug.DrawRay(groundCheck.position, Vector2.down * margenSalto, puedeSaltar ? Color.green : Color.red);
    }

    private bool IsPointerOverUI()
    {
        // Verifica si el toque actual colisiona con algún elemento de la UI (Canvas/Joystick)
        if (EventSystem.current == null) return false;
        
        return EventSystem.current.IsPointerOverGameObject();
    }
}