using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class PersonajeLogica : MonoBehaviour
{
    [Header("Límites y Respawn")]
    public float limiteY = -8.63f;
    public ParticleSystem checkpointParticles;
    
    private Vector3 respawnPoint;
    private Rigidbody2D rb;
    private bool juegoTerminado = false;

    // Propiedad pública para que otros scripts (movimiento/salto) 
    // sepan si pueden actuar o no
    public bool JuegoTerminado => juegoTerminado;

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        respawnPoint = transform.position;
        
        // Mantiene la física activa pero estable
        rb.freezeRotation = true; 
        Time.timeScale = 1f;
    }

    void FixedUpdate()
    {
        if (juegoTerminado) return;

        // Si cae por debajo del abismo, reaparece
        if (transform.position.y < limiteY) 
        {
            Respawn();
        }
    }

    private void OnTriggerEnter2D(Collider2D col)
    {
        if (juegoTerminado) return;

        // Sistema de Recolección
        if (col.CompareTag("Moneda"))
        {
            if (UI_Controlador.Instance != null) UI_Controlador.Instance.SumarMoneda();
            Destroy(col.gameObject);
        }
        // Peligros
        else if (col.CompareTag("Bomba"))
        {
            Respawn();
        }
        // Puntos de Guardado
        else if (col.CompareTag("Checkpoint"))
        {
            respawnPoint = col.transform.position;
        }
        // Condición de Victoria
        else if (col.CompareTag("Meta"))
        {
            Victoria();
        }
    }

    public void Respawn()
    {
        rb.linearVelocity = Vector2.zero;
        transform.position = respawnPoint;
        
        if (checkpointParticles != null) 
        {
            Instantiate(checkpointParticles, transform.position, Quaternion.identity);
        }
    }

    private void Victoria()
    {
        juegoTerminado = true;
        rb.linearVelocity = Vector2.zero;
        // Congelamos el tiempo o disparamos UI de victoria aquí
        Time.timeScale = 0f; 
        Debug.Log("¡Nivel Completado!");
    }
}