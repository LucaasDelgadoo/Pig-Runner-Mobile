using UnityEngine;

public class JoystickMove : MonoBehaviour
{
    public Joystick movementJoystick;
    public float playerSpeed = 5f;
    private Rigidbody2D rb;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        
        // Evitamos que el personaje ruede sobre sí mismo al chocar
        rb.freezeRotation = true; 
    }

    private void FixedUpdate()
    {
        // 1. Obtenemos solo el valor horizontal del joystick
        float horizontalInput = movementJoystick.Direction.x;

        // 2. Aplicamos la velocidad:
        // En X: El input multiplicado por la velocidad.
        // En Y: Mantenemos la velocidad actual del Rigidbody (la gravedad).
        rb.linearVelocity = new Vector2(horizontalInput * playerSpeed, rb.linearVelocity.y);

        // 3. Opcional: Girar el personaje visualmente según la dirección
        if (horizontalInput != 0)
        {
            transform.localScale = new Vector3(Mathf.Sign(horizontalInput) * Mathf.Abs(transform.localScale.x), transform.localScale.y, transform.localScale.z);
        }
    }
}